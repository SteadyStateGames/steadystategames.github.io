'use strict';
function distracted(url) {
  try {
    const host = new URL(url).hostname.toLowerCase();
    return ['youtube.com', 'tiktok.com'].some(domain => host === domain || host.endsWith('.' + domain)) || host === 'youtu.be';
  } catch { return false; }
}
let operations = Promise.resolve();
async function sample() {
  const window = await chrome.windows.getLastFocused();
  const [tab] = window.focused ? await chrome.tabs.query({ active: true, windowId: window.id }) : [];
  const active = Boolean(tab && !tab.incognito && distracted(tab.url));
  const { timeline = { active: false, seq: 0, events: [] } } = await chrome.storage.session.get('timeline');
  if (active !== timeline.active) {
    timeline.active = active;
    timeline.seq++;
    timeline.events.push({ active, at: Date.now() / 1000, seq: timeline.seq });
    timeline.events = timeline.events.slice(-2000);
    await chrome.storage.session.set({ timeline });
  }
  return timeline;
}
function update() {
  const task = operations.then(sample);
  operations = task.catch(() => {});
  return task;
}
chrome.tabs.onActivated.addListener(() => { update().catch(() => {}); });
chrome.tabs.onUpdated.addListener((_id, change) => { if (change.url || change.status) update().catch(() => {}); });
chrome.tabs.onRemoved.addListener(() => { update().catch(() => {}); });
chrome.windows.onFocusChanged.addListener(() => { update().catch(() => {}); });
chrome.alarms.onAlarm.addListener(() => { update().catch(() => {}); });
chrome.runtime.onInstalled.addListener(() => { chrome.alarms.create('sample', { periodInMinutes: .5 }); update().catch(() => {}); });
chrome.runtime.onStartup.addListener(() => { chrome.alarms.create('sample', { periodInMinutes: .5 }); update().catch(() => {}); });
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (message?.type !== 'pomodoro-poll' || !sender.tab || !/^(https:\/\/steadystategames\.dev\/pomodoro\/|http:\/\/127\.0\.0\.1:4177\/)/.test(sender.url || '')) return;
  update().then(timeline => respond({ active: timeline.active, seq: timeline.seq,
    events: Number.isFinite(message.after) ? timeline.events.filter(event => event.seq > message.after) : [] }))
    .catch(() => respond({ error: true }));
  return true;
});
