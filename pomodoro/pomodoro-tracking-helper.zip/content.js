'use strict';
let cursor;
async function poll() {
  try {
    const result = await chrome.runtime.sendMessage({ type: 'pomodoro-poll', after: cursor });
    if (!result || result.error) return;
    cursor = result.seq;
    window.postMessage({ type: 'pomodoro-distraction', active: result.active, events: result.events }, location.origin);
  } catch { /* Extension reload or page navigation; retry on the next poll. */ }
}
poll();
setInterval(poll, 1000);
document.addEventListener('visibilitychange', poll);
window.addEventListener('pageshow', poll);
