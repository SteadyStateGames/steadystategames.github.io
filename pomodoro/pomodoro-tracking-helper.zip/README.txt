Pomodoro Distraction Timer — optional Chrome / Edge helper

1. Extract this ZIP to a folder you will keep.
2. Open chrome://extensions (or edge://extensions).
3. Enable Developer mode, choose Load unpacked, and select the extracted folder.
4. Reload https://steadystategames.dev/pomodoro/.
5. Select Work stopwatch. In Settings > Tracking, enable automatic tracking.

While your stopwatch is running, a foreground YouTube (including Shorts or
youtu.be) or TikTok tab switches it to red distraction time. Other tabs and
applications count as work. Pause the stopwatch for breaks. You can use the
Work / Distraction buttons manually without this helper.

Detection covers this browser only. It cannot detect phone use or desktop
YouTube/TikTok apps. Keep the Pomodoro page open. A suspended/frozen page
reconciles recent tab transitions when it resumes. History is limited to
2,000 category transitions per browser session.

The helper uses only the listed site permissions and stores work/distraction
category transitions in browser-session storage. It sends no URLs, titles,
page contents or browsing data to a server. It does not block websites.
Disable or remove it on the browser's Extensions page whenever you wish.
