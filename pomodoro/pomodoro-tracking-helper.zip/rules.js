'use strict';
(() => {
  const DEFAULTS = { tracked_sites: ['youtube.com', 'youtu.be', 'tiktok.com'],
    allow: { youtube_video_ids: [], youtube_playlist_ids: [], rules: [] } };
  const strings = value => Array.isArray(value) && value.every(item => typeof item === 'string' && item.length > 0);
  function site(value) {
    if (typeof value !== 'string' || !/^[a-z0-9.-]+$/i.test(value) || value.startsWith('.') || value.endsWith('.') || value.includes('..')) throw new Error('Sites must be hostnames such as facebook.com, without https:// or paths.');
    return value.toLowerCase();
  }
  function compile(config) {
    if (!config || !strings(config.tracked_sites)) throw new Error('tracked_sites must be an array of hostnames.');
    const allow = config.allow || {};
    const videos = allow.youtube_video_ids || [], playlists = allow.youtube_playlist_ids || [], rules = allow.rules || [];
    if (!strings(videos) || !strings(playlists) || !Array.isArray(rules)) throw new Error('Invalid allow list.');
    return { tracked_sites: config.tracked_sites.map(site), allow: {
      youtube_video_ids: videos, youtube_playlist_ids: playlists,
      rules: rules.map(rule => {
        if (!rule || typeof rule !== 'object') throw new Error('Each allow rule needs a site.');
        const result = { site: site(rule.site) };
        for (const field of ['path', 'path_prefix']) {
          if (rule[field] !== undefined) {
            if (typeof rule[field] !== 'string' || !rule[field].startsWith('/')) throw new Error('Rule paths must start with /.');
            result[field] = rule[field];
          }
        }
        if (rule.query !== undefined) {
          if (!rule.query || typeof rule.query !== 'object' || Array.isArray(rule.query) || !Object.values(rule.query).every(value => typeof value === 'string')) throw new Error('Rule query values must be strings.');
          result.query = rule.query;
        }
        return result;
      }),
    } };
  }
  const matchesSite = (host, domain) => host === domain || host.endsWith('.' + domain);
  function distracted(raw, config) {
    try {
      const url = new URL(raw), host = url.hostname.toLowerCase();
      if (!['https:', 'http:'].includes(url.protocol) || !config.tracked_sites.some(domain => matchesSite(host, domain))) return false;
      const youtube = matchesSite(host, 'youtube.com') || host === 'youtu.be';
      if (youtube) {
        let video = host === 'youtu.be' ? url.pathname.split('/')[1] : url.searchParams.get('v');
        if (!video && /^\/(shorts|embed|live)\//.test(url.pathname)) video = url.pathname.split('/')[2];
        if (video && config.allow.youtube_video_ids.includes(video)) return false;
        const playlist = url.searchParams.get('list');
        if (playlist && config.allow.youtube_playlist_ids.includes(playlist)) return false;
      }
      if (config.allow.rules.some(rule => matchesSite(host, rule.site)
        && (rule.path === undefined || url.pathname === rule.path)
        && (rule.path_prefix === undefined || url.pathname.startsWith(rule.path_prefix))
        && Object.entries(rule.query || {}).every(([key, value]) => url.searchParams.get(key) === value))) return false;
      return true;
    } catch { return false; }
  }
  const api = { DEFAULTS, compile, distracted };
  if (typeof module !== 'undefined') module.exports = api;
  globalThis.PomodoroRules = api;
})();
